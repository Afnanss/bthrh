<!DOCTYPE html>
<!--weeb-->
<html>
<head>
  <meta charset ="utf-8">
  <title>بذرة </title>
  <h1><img src="https://i.dlpng.com/static/png/6647896_preview.png" alt= "bathrah logo" width="200" height="150"></h1>

  <style>
    h1 {

      text-align: center;
    }
  ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #daf1e4;
          text-align: center;
    }
    li {
        float: right;
    }

    li a {
        display: block;
        color: #1c4a30;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    li a:hover {
        background-color: #7dcfa7;
    }

    .show:hover ul.list-categories{
  max-height: inherit;
  opacity: 1;
  background-color: #7dcfa7;
  display: block;
}

.list-categories{
  list-style-type: none;
  padding: 0px;
  margin: 0px;
  max-height: 0px;
  opacity: 0;
  overflow: hidden;
  transition: opacity 300ms ease;
}

.container {
  display: flex;
}

img {
  margin : 60px;
}
.box{
  background-color: #e8e3da;
  font-size: 15px;
height : 500px;
margin: 80px;
text-align :center;
color:#6b6250;

}
</style>
</head>
<body>


<ul>
  <li><a href="login.php">تسجيل</a></li>
  <li><a href="index.php">الرئيسية</a></li>
    <li><a href="location.php">مشاتل بجواري </a></li>
  <li><div class="show"><a href="types.php">التصنيفات</a>
<ul class="list-categories">
<li><a href="indoorplants.php">النباتات الداخلية </a> <br>
  </li><br/>
  <br/> 
  <li><a href="outdoorplants.php">النباتات الخارجية</a>
  <br></li><br/> <br/>
  <li><a href="flowerscactus.php">زهور وصبار<br></a>
  </li><br/> <br/>
   <li><a href="harmfulplants.php">نباتات ضارة للحيوانات<br></a>
  </li><br/> <br/>
</ul>
</div>
    <li> <div class="show"><a>حسابي</a>
    <ul class="list-categories">
      <li><a href="logout.php">تسجيل الخروج</a>
      </li></ul>
    </ul>
  </div>

<br><br><br>


<div class="container">
  <img src="https://cdn.shopify.com/s/files/1/0150/6262/products/the-sill_bird-of-paradise_variant_large_grant_pale-grey_1200x.jpg?v=1603635940" height="600" alt="hawraa">
  <div class="box"><h1>عصفور الجنة</h1> <br> <h2>
الري<br> </h2>
لا يتم ريها إلا بعد جفاف التربة جزئيا وعند جفاف سطح التربة مع عدم اغراقها بالماء<br><h2>
 الاضاءة<br></h2>
تحتاج ضوء ساطع داخل المنزل قريبا من النوافذ الكبيرة لتوفير الإضاءة الطبيعية مع عدم التعرض

.المباشر للشمس<br><h2>
 درجة الحرارة<br></h2>
حتاج إلى جو معتدل ويناسبها درجة حرارة الغرفة الطبيعية وتتحمل الجو الدافئ حتى 30 درجة مئوي
<h2>
الوصف<br></h2>
نبتة كبيرة الاوراق جميلة الشكل تحتاج للإضاءة الساطعة وضوء الشمس بشكل غير مباشر، من الطبيعي وجود تشققات في أوراقها
</div>

</div>




</body>
</html>
